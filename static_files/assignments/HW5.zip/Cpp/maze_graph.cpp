/********************************************************************************
 * Author: [Your Name]
 * Date: [Date of Creation or Last Update]
 * Purpose: 
 ********************************************************************************/

#include "CTurtle.hpp" // Include the C-Turtle header
#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <algorithm> // For std::find
#include <memory> // For std::unique_ptr
#include <sstream>
#include <cctype>
#include "adjacency_graph.cpp"
#include "stack.cpp"
#include "queue.cpp"
#include "binary_heap.cpp"

namespace ct = cturtle; // Namespace alias for convenience

const char START = 'S';
const char OBSTACLE = '+';
const char TRIED = '.';
const char DEAD_END = '-';
const char PART_OF_PATH = 'O';

class Maze {
public:
    std::vector<std::vector<char>> maze_list;
    int rows_in_maze, columns_in_maze;
    int start_row, start_col;
    std::unique_ptr<ct::TurtleScreen> screen;
    std::unique_ptr<ct::Turtle> turtle;
    bool use_gui; // Flag to control GUI usage

    Maze(const std::string& maze_filename, bool use_gui = true) : use_gui(use_gui) {
        std::ifstream maze_file(maze_filename);
        std::string line;
        while (std::getline(maze_file, line)) {
            std::vector<char> row;
            for (char ch : line) row.push_back(ch);
            maze_list.push_back(row);
        }
        rows_in_maze = maze_list.size();
        columns_in_maze = maze_list[0].size();
        for (int row_idx = 0; row_idx < rows_in_maze; ++row_idx) {
            for (int col_idx = 0; col_idx < columns_in_maze; ++col_idx) {
                if (maze_list[row_idx][col_idx] == START) {
                    start_row = row_idx;
                    start_col = col_idx;
                    break;
                }
            }
        }

        if (use_gui) {
            // Conditionally create screen and turtle only if GUI is used
            screen = std::make_unique<ct::TurtleScreen>();
            turtle = std::make_unique<ct::Turtle>(*screen);
            
            screen->tracer(0, 0); // Disable animation for faster drawing
            turtle->speed(ct::TS_FASTEST);
            draw_maze();
            turtle->speed(ct::TS_SLOW); // Set turtle speed to fastest
        }
    }

    void draw_maze() {
        if (!use_gui) return; // Skip drawing if GUI is not used

        turtle->penup();
        for (int row = 0; row < rows_in_maze; ++row) {
            for (int col = 0; col < columns_in_maze; ++col) {
                int x = (col - columns_in_maze / 2) * 20;
                int y = (rows_in_maze / 2 - row) * 20;
                turtle->goTo(x, y);
                if (maze_list[row][col] == OBSTACLE) {
                    draw_box();
                }
            }
        }
        screen->update(true, false); // Update the screen after all drawings
        screen->tracer(10, 10);
    }

    void draw_box() {
        if (!use_gui) return; // Skip box drawing if GUI is not used

        turtle->begin_fill();
        turtle->fillcolor(ct::Color("orange"));
        for (int i = 0; i < 4; ++i) {
            turtle->forward(20);
            turtle->right(90);
        }
        turtle->end_fill();
    }

    bool is_exit(int row, int col) {
        return row == 0 || row == rows_in_maze - 1 || col == 0 || col == columns_in_maze - 1;
    }

    bool update_position(int row, int col, char val = ' ') {
        if (!use_gui) {
            // Update maze list directly without GUI operations
            if (val != ' ') {
                maze_list[row][col] = val;
            }
            return true;
        }

        // GUI operations for updating position
        int x = (col - columns_in_maze / 2) * 20 + 10; // Adjust for cell center
        int y = (rows_in_maze / 2 - row) * 20 - 10;
        turtle->goTo(x, y);
        if (val != ' ') {
            maze_list[row][col] = val;
            if (val == PART_OF_PATH) {
                turtle->dot(ct::Color("green"), 10);
            } else if (val == TRIED) {
                turtle->dot(ct::Color("blue"), 10);
            } else if (val == DEAD_END) {
                turtle->dot(ct::Color("red"), 10);
            }
        }
        return true;
    }
};

void build_graph(const Maze& maze, Graph& graph) {
    int rows = maze.rows_in_maze;
    int cols = maze.columns_in_maze;

    for (int r = 0; r < rows; r++) {
        for (int c = 0; c < cols; c++) {
            if (maze.maze_list[r][c] != OBSTACLE) {
                std::string node_id = std::to_string(r) + "-" + std::to_string(c);
                if (!graph.contains(node_id)) {
                    graph.addVertex(node_id);
                }
                // Directions: Up, Down, Left, Right
                std::vector<std::pair<int, int>> directions = {{-1, 0}, {1, 0}, {0, -1}, {0, 1}};
                for (auto& dir : directions) {
                    int nr = r + dir.first, nc = c + dir.second;
                    if (nr >= 0 && nr < rows && nc >= 0 && nc < cols && maze.maze_list[nr][nc] != OBSTACLE) {
                        std::string neighbor_id = std::to_string(nr) + "-" + std::to_string(nc);
                        if (!graph.contains(neighbor_id)) {
                            graph.addVertex(neighbor_id);
                        }
                        graph.addEdge(node_id, neighbor_id);  // Add edge in one direction
                        graph.addEdge(neighbor_id, node_id);  // Ensure the edge is bidirectional
                    }
                }
            }
        }
    }
}


bool search_from_graph_dfs(Maze& maze, Graph& graph, int start_row, int start_col, std::vector<std::pair<int, int>>& path) {
    std::string start_id = std::to_string(start_row) + "-" + std::to_string(start_col);
    Vertex* start_vertex = graph.getVertex(start_id);
    if (!start_vertex) {
        std::cout << "Start vertex does not exist." << std::endl;
        return false;
    }

    Stack<Vertex*> stack(graph.numVertices);  // Use the custom Stack class
    start_vertex->color = "gray";
    maze.update_position(start_row, start_col, TRIED);  // Mark the initial position as tried
    stack.push(start_vertex);

    while (!stack.isEmpty()) {
        Vertex* vertex = stack.peek(0);  // Peek at the top vertex without popping it
        int row = std::stoi(vertex->getId().substr(0, vertex->getId().find('-')));
        int col = std::stoi(vertex->getId().substr(vertex->getId().find('-') + 1));
        bool all_neighbors_visited = true;

        if (vertex->color == "white") {
            vertex->color = "gray";
            vertex->discovery_time = ++graph.time;
            maze.update_position(row, col, TRIED);  // Mark this vertex as tried
        }

        std::vector<std::pair<int, int>> directions = {{-1, 0}, {1, 0}, {0, -1}, {0, 1}};  // Up, Down, Left, Right
        for (const auto& dir : directions) {
            int nr = row + dir.first, nc = col + dir.second;
            std::string neighbor_id = std::to_string(nr) + "-" + std::to_string(nc);
            if (nr >= 0 && nr < maze.rows_in_maze && nc >= 0 && nc < maze.columns_in_maze) {
                Vertex* neighbor = graph.getVertex(neighbor_id);
                if (neighbor && neighbor->color == "white") {
                    neighbor->color = "gray";
                    neighbor->previous = vertex;
                    neighbor->discovery_time = ++graph.time;
                    maze.update_position(nr, nc, TRIED);  // Mark each new neighbor as tried when first visited
                    stack.push(neighbor);
                    all_neighbors_visited = false;
                    break;  // Stop and explore this new neighbor first
                }
            }
        }

        if (all_neighbors_visited) {
            stack.pop();  // Fully processed, pop from stack
            vertex->color = "black";
            vertex->closing_time = ++graph.time;

            if (maze.is_exit(row, col)) {
                path.push_back({row, col});
                maze.update_position(row, col, PART_OF_PATH);
                while (vertex->previous) {
                    vertex = vertex->previous;
                    row = std::stoi(vertex->getId().substr(0, vertex->getId().find('-')));
                    col = std::stoi(vertex->getId().substr(vertex->getId().find('-') + 1));
                    path.push_back({row, col});
                    maze.update_position(row, col, PART_OF_PATH);  // Mark the path from exit to start
                }
                std::reverse(path.begin(), path.end());
                return true;
            }
        }
    }

    return false;  // No path found if stack empties
}

// Do not modify the code above
bool search_from_graph_bfs(Maze& maze, Graph& graph, int start_row, int start_col, std::vector<std::pair<int, int>>& path) {
// Your code here
}


bool search_from_graph_dijkstra(Maze& maze, Graph& graph, int start_row, int start_col, std::vector<std::pair<int, int>>& path) {
// Your code here
}
// Do not modify the code below


bool naturalSort(const std::string& a, const std::string& b) {
    std::istringstream issA(a), issB(b);
    while (issA.good() && issB.good()) {
        if (isdigit(issA.peek()) && isdigit(issB.peek())) {
            int intA, intB;
            issA >> intA;
            issB >> intB;
            if (intA != intB) return intA < intB;
        } else {
            char charA, charB;
            issA >> charA;
            issB >> charB;
            if (charA != charB) return charA < charB;
        }
    }
    return issA.good() < issB.good();  // continue comparison if one string ended
}

void printGraphStatus(const Graph& graph) {
    std::cout << "Vertex Status:\n";
    std::cout << "ID | Color | Distance | Discovery Time | Closing Time | Previous\n";

    // Extract and sort keys naturally
    std::vector<std::string> keys;
    for (const auto& vertexPair : graph.vertList) {
        keys.push_back(vertexPair.first);
    }
    std::sort(keys.begin(), keys.end(), naturalSort);

    // Print vertices in sorted order
    for (const auto& key : keys) {
        std::cout << graph.vertList.at(key).to_string() << std::endl;
    }
}


int main(int argc, char* argv[]) {
    if (argc < 2) {
        std::cout << "Usage: ./maze_solver maze.txt [correct_path.txt] [algorithm] [--nogui]" << std::endl;
        return 1;
    }

    std::string maze_filename = argv[1];
    std::string algorithm = "dfs";  // Default to using DFS
    std::string correct_path_filename;
    bool use_gui = true;  // Default to using GUI

    // Parse command line arguments
    for (int i = 2; i < argc; ++i) {
        std::string arg = argv[i];
        if (arg == "--nogui") {
            use_gui = false;
        } else if (arg == "dfs" || arg == "bfs" || arg == "dijkstra") {
            algorithm = arg;
        } else {
            correct_path_filename = arg;
        }
    }
 
    // Reinitialize the maze for actual algorithm execution
    Maze my_maze(maze_filename, use_gui); // Pass use_gui to the Maze constructor
    Graph graph; // Instantiate a Graph object
    build_graph(my_maze, graph);
    std::vector<std::pair<int, int>> path;
    bool path_found = false;

    if (algorithm == "dfs") {
        path_found = search_from_graph_dfs(my_maze, graph, my_maze.start_row, my_maze.start_col, path);
    } else if (algorithm == "bfs") {
        path_found = search_from_graph_bfs(my_maze, graph, my_maze.start_row, my_maze.start_col, path);
    } else if (algorithm == "dijkstra") {
        path_found = search_from_graph_dijkstra(my_maze, graph, my_maze.start_row, my_maze.start_col, path);
    }

    printGraphStatus(graph);

    if (path_found) {
        std::cout << "Path found using " << algorithm << ". Total path length: " << path.size()-1 << std::endl;
        for (const auto& p : path) {
            std::cout << "(" << p.first << ", " << p.second << ")" << std::endl;
        }
    } else {
        std::cout << "No path found using " << algorithm << "." << std::endl;
    }

    // Compare with correct path if provided
    if (!correct_path_filename.empty()) {
        std::ifstream path_file(correct_path_filename);
        std::vector<std::pair<int, int>> correct_path;
        int row, col;
        while (path_file >> row >> col) {
            correct_path.emplace_back(row, col);
        }

        if (path == correct_path) {
            std::cout << "The search path matches the correct path!" << std::endl;
        } else {
            std::cout << "The search path does not match the correct path." << std::endl;
        }
    }

    // Only attempt to call mainloop if the screen has been instantiated and GUI is enabled
    if (use_gui && my_maze.screen != nullptr) {
        my_maze.screen->mainloop();
    }

    return 0;
}
