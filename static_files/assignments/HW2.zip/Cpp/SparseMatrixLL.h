/********************************************************************************
 * Author: [Your Name]
 * Date: [Date of Creation or Last Update]
 * Purpose: 
 ********************************************************************************/


#ifndef SPARSEMATRIXLL_H
#define SPARSEMATRIXLL_H

#include <iostream>
#include <stdexcept>
#include <vector>
#include <sstream>
#include "linked_list.cpp"

using namespace std;

// MatrixEntry class
class MatrixEntry {
public:
    int col;
    int val;
    MatrixEntry();
    MatrixEntry(int column_number, int value);
    bool operator==(const MatrixEntry &other) const;
};

// SparseMatrixLL class
class SparseMatrixLL {
private:
    int _nrows, _ncols;
    vector<UnorderedList<MatrixEntry>> _row_list;

    void check_row(int row) const;
    void check_col(int col) const;

public:
    SparseMatrixLL(int nrows, int ncols);

    void set(int row, int col, int value);
    int get(int row, int col) const;
    SparseMatrixLL operator+(const SparseMatrixLL& other) const;
    SparseMatrixLL operator-(const SparseMatrixLL& other) const;
    SparseMatrixLL operator*(const SparseMatrixLL& other) const;

    int len() const;

    void from_dense_matrix(const std::vector<std::vector<int>>& dense_matrix);
    std::vector<std::vector<int>> to_dense() const;

    void printout() const;
    friend std::ostream& operator<<(std::ostream& os, const SparseMatrixLL& matrix);
};

#endif // SPARSEMATRIXLL_H
