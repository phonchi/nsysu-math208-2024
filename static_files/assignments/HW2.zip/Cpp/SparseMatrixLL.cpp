/********************************************************************************
 * Author: [Your Name]
 * Date: [Date of Creation or Last Update]
 * Purpose: 
 ********************************************************************************/
 
#include "SparseMatrixLL.h"

using namespace std;


// MatrixEntry class implementations
/**
 * Constructor for MatrixEntry with column number and value.
 * 
 * Args:
 *     column_number (int): The column number of the entry.
 *     value (int): The value of the entry.
 */
MatrixEntry::MatrixEntry(int column_number, int value) : col(column_number), val(value) {}

/**
 * Default constructor for MatrixEntry.
 */
MatrixEntry::MatrixEntry() : col(0), val(0) {}

/**
 * Overload the equality operator for comparing two MatrixEntry objects.
 * 
 * Args:
 *     other (const MatrixEntry&): The MatrixEntry object to compare with.
 * 
 * Return:
 *     bool: True if both MatrixEntry objects have the same column number, False otherwise.
 */
bool MatrixEntry::operator==(const MatrixEntry &other) const {
    return col == other.col;
}

// SparseMatrixLL class implementations
/**
 * Constructor for SparseMatrixLL with specified number of rows and columns.
 * 
 * Args:
 *     nrows (int): The number of rows in the matrix.
 *     ncols (int): The number of columns in the matrix.
 */
SparseMatrixLL::SparseMatrixLL(int nrows, int ncols {

}


/**
 * Set a value at a specific row and column index.
 * 
 * Args:
 *     row (int): The row index.
 *     col (int): The column index.
 *     value (int): The value to set.
 */
void SparseMatrixLL::set(int row, int col, int value) {

}

/**
 * Get a value from a specific row and column index.
 * 
 * Args:
 *     row (int): The row index.
 *     col (int): The column index.
 * 
 * Return:
 *     int: The value at the specified row and column index.
 */
int SparseMatrixLL::get(int row, int col) const {

}

/**
 * Overload the addition operator to add two SparseMatrixLL instances.
 * 
 * Args:
 *     other (const SparseMatrixLL&): The SparseMatrixLL instance to add.
 * 
 * Return:
 *     SparseMatrixLL: A new SparseMatrixLL instance representing the sum.
 */
SparseMatrixLL SparseMatrixLL::operator+(const SparseMatrixLL& other) const {

}

/**
 * Overload the subtraction operator to subtract another SparseMatrixLL instance from this one.
 * 
 * Args:
 *     other (const SparseMatrixLL&): The SparseMatrixLL instance to subtract.
 * 
 * Return:
 *     SparseMatrixLL: A new SparseMatrixLL instance representing the difference.
 */
SparseMatrixLL SparseMatrixLL::operator-(const SparseMatrixLL& other) const {

}

/**
 * Overload the multiplication operator to multiply this SparseMatrixLL instance with another.
 * 
 * Args:
 *     other (const SparseMatrixLL&): The SparseMatrixLL instance to multiply with.
 * 
 * Return:
 *     SparseMatrixLL: A new SparseMatrixLL instance representing the product.
 */
SparseMatrixLL SparseMatrixLL::operator*(const SparseMatrixLL& other) const {

}



// Do not modify the code below
/**
 * Check if the given row index is within the valid range.
 * 
 * Args:
 *     row (int): The row index to check.
 * 
 * Throws:
 *     out_of_range: If the row index is out of range.
 */
void SparseMatrixLL::check_row(int row) const {
    if (row < 0 || row >= _nrows) {
        throw out_of_range("Row number is out of range");
    }
}

/**
 * Check if the given column index is within the valid range.
 * 
 * Args:
 *     col (int): The column index to check.
 * 
 * Throws:
 *     out_of_range: If the column index is out of range.
 */
void SparseMatrixLL::check_col(int col) const {
    if (col < 0 || col >= _ncols) {
        throw out_of_range("Column number is out of range");
    }
}

/**
 * Calculate the total number of non-zero entries in the matrix.
 * 
 * Return:
 *     int: The number of non-zero entries.
 */
int SparseMatrixLL::len() const {
    int total_entries = 0;
    for (const auto& row_list : _row_list) {
        Node<MatrixEntry>* current = row_list.getHead();
        while (current) {
            total_entries++;
            current = current->getNext();
        }
    }
    return total_entries;
}

/**
 * Populate this sparse matrix from a dense matrix.
 * 
 * Args:
 *     dense_matrix (const std::vector<std::vector<int>>&): The dense matrix to convert from.
 */
void SparseMatrixLL::from_dense_matrix(const std::vector<std::vector<int>>& dense_matrix) {
    if (dense_matrix.empty() || dense_matrix[0].empty()) {
        throw std::invalid_argument("Dense matrix must be non-empty");
    }
    int nrows = dense_matrix.size();
    int ncols = dense_matrix[0].size();
    if (nrows != _nrows || ncols != _ncols) {
        throw std::invalid_argument("Dense matrix dimensions must match the sparse matrix dimensions");
    }
    for (int i = 0; i < _nrows; ++i) {
        for (int j = 0; j < _ncols; ++j) {
            if (dense_matrix[i][j] != 0) { // Only add non-zero values
                this->set(i, j, dense_matrix[i][j]);
            }
        }
    }
}

/**
 * Convert this sparse matrix to a dense matrix representation.
 * 
 * Return:
 *     std::vector<std::vector<int>>: A dense matrix representation of this sparse matrix.
 */
std::vector<std::vector<int>> SparseMatrixLL::to_dense() const {
    std::vector<std::vector<int>> dense_matrix(_nrows, std::vector<int>(_ncols, 0));
    for (int i = 0; i < _nrows; ++i) {
        for (int j = 0; j < _ncols; ++j) {
            dense_matrix[i][j] = this -> get(i, j);
        }
    }
    return dense_matrix;
}

/**
 * Print out the non-zero entries of the matrix in a readable format.
 */
void SparseMatrixLL::printout() const {
    for (int i = 0; i < _nrows; ++i) {
        bool rowHasNonZero = false;
        std::stringstream ss;
        ss << "[" << i << "]:";
        for (int j = 0; j < _ncols; ++j) {
            int value = this -> get(i, j);
            if (value != 0) {
                ss << " " << j << ": " << value;
                rowHasNonZero = true;
            }
        }
        if (rowHasNonZero) {
            std::cout << ss.str() << std::endl;
        }
    }
}

/**
 * Overload the stream insertion operator to output the matrix to an output stream.
 * 
 * Args:
 *     os (std::ostream&): The output stream.
 *     matrix (const SparseMatrixLL&): The SparseMatrixLL instance to output.
 * 
 * Return:
 *     std::ostream&: The output stream.
 */
std::ostream& operator<<(std::ostream& os, const SparseMatrixLL& matrix) {
    for (int i = 0; i < matrix._nrows; ++i) {
        for (int j = 0; j < matrix._ncols; ++j) {
            os << matrix.get(i, j) << " ";
        }
        os << "\n";
    }
    return os;
}
// Do not modify the code above


