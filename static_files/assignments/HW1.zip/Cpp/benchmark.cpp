/********************************************************************************
 * Author: [Your Name]
 * Date: [Date of Creation or Last Update]
 * Purpose: 
 ********************************************************************************/

#include <iostream>
#include <vector>
#include <ctime>
#include "Polynomial.h"  // Include your Polynomial class implementation

