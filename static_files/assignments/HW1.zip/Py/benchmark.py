# Author: [Your Name]
# Date: [Date of Creation or Last Update]
# Purpose: 

import time
from timeit import Timer
from Polynomial import Polynomial


