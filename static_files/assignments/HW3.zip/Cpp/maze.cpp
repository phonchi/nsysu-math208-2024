#include "CTurtle.hpp" // Include the C-Turtle header
#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <algorithm> // For std::find
#include <memory> // For std::unique_ptr

namespace ct = cturtle; // Namespace alias for convenience

const char START = 'S';
const char OBSTACLE = '+';
const char TRIED = '.';
const char DEAD_END = '-';
const char PART_OF_PATH = 'O';

class Maze {
public:
    std::vector<std::vector<char>> maze_list;
    int rows_in_maze, columns_in_maze;
    int start_row, start_col;
    std::unique_ptr<ct::TurtleScreen> screen;
    std::unique_ptr<ct::Turtle> turtle;
    bool use_gui; // Flag to control GUI usage

    Maze(const std::string& maze_filename, bool use_gui = true) : use_gui(use_gui) {
        std::ifstream maze_file(maze_filename);
        std::string line;
        while (std::getline(maze_file, line)) {
            std::vector<char> row;
            for (char ch : line) row.push_back(ch);
            maze_list.push_back(row);
        }
        rows_in_maze = maze_list.size();
        columns_in_maze = maze_list[0].size();
        for (int row_idx = 0; row_idx < rows_in_maze; ++row_idx) {
            for (int col_idx = 0; col_idx < columns_in_maze; ++col_idx) {
                if (maze_list[row_idx][col_idx] == START) {
                    start_row = row_idx;
                    start_col = col_idx;
                    break;
                }
            }
        }

        if (use_gui) {
            // Conditionally create screen and turtle only if GUI is used
            screen = std::make_unique<ct::TurtleScreen>();
            turtle = std::make_unique<ct::Turtle>(*screen);
            
            screen->tracer(0, 0); // Disable animation for faster drawing
            turtle->speed(ct::TS_FASTEST);
            draw_maze();
            turtle->speed(ct::TS_SLOW); // Set turtle speed to fastest
        }
    }

    void draw_maze() {
        if (!use_gui) return; // Skip drawing if GUI is not used

        turtle->penup();
        for (int row = 0; row < rows_in_maze; ++row) {
            for (int col = 0; col < columns_in_maze; ++col) {
                int x = (col - columns_in_maze / 2) * 20;
                int y = (rows_in_maze / 2 - row) * 20;
                turtle->goTo(x, y);
                if (maze_list[row][col] == OBSTACLE) {
                    draw_box();
                }
            }
        }
        screen->update(true, false); // Update the screen after all drawings
        screen->tracer(10, 10);
    }

    void draw_box() {
        if (!use_gui) return; // Skip box drawing if GUI is not used

        turtle->begin_fill();
        turtle->fillcolor(ct::Color("orange"));
        for (int i = 0; i < 4; ++i) {
            turtle->forward(20);
            turtle->right(90);
        }
        turtle->end_fill();
    }

    bool is_exit(int row, int col) {
        return row == 0 || row == rows_in_maze - 1 || col == 0 || col == columns_in_maze - 1;
    }

    bool update_position(int row, int col, char val = ' ') {
        if (!use_gui) {
            // Update maze list directly without GUI operations
            if (val != ' ') {
                maze_list[row][col] = val;
            }
            return true;
        }

        // GUI operations for updating position
        int x = (col - columns_in_maze / 2) * 20 + 10; // Adjust for cell center
        int y = (rows_in_maze / 2 - row) * 20 - 10;
        turtle->goTo(x, y);
        if (val != ' ') {
            maze_list[row][col] = val;
            if (val == PART_OF_PATH) {
                turtle->dot(ct::Color("green"), 10);
            } else if (val == TRIED) {
                turtle->dot(ct::Color("blue"), 10);
            } else if (val == DEAD_END) {
                turtle->dot(ct::Color("red"), 10);
            }
        }
        return true;
    }
};

bool search_from(Maze& maze, int row, int column, std::vector<std::pair<int, int>>& path) {
    if (maze.maze_list[row][column] == OBSTACLE || maze.maze_list[row][column] == TRIED || maze.maze_list[row][column] == DEAD_END) {
        return false;
    }
    if (maze.is_exit(row, column)) {
        maze.update_position(row, column, PART_OF_PATH);
        path.push_back(std::make_pair(row, column));
        return true;
    }
    maze.update_position(row, column, TRIED);
    path.push_back(std::make_pair(row, column));

    if (search_from(maze, row - 1, column, path) ||
        search_from(maze, row + 1, column, path) ||
        search_from(maze, row, column - 1, path) ||
        search_from(maze, row, column + 1, path)) {
        maze.update_position(row, column, PART_OF_PATH);
        return true;
    }

    maze.update_position(row, column, DEAD_END);
    path.pop_back();
    return false;
}

int main(int argc, char* argv[]) {
    if (argc < 2) {
        std::cout << "Usage: ./maze_solver maze.txt [correct_path.txt] [--nogui]" << std::endl;
        return 1;
    }

    std::string maze_filename = argv[1];
    std::string correct_path_filename;
    bool use_gui = true; // Default to using GUI

    // Parse command line arguments for nogui and correct path file
    for (int i = 2; i < argc; ++i) {
        std::string arg = argv[i];
        if (arg == "--nogui") {
            use_gui = false;
        } else {
            correct_path_filename = arg;
        }
    }

    Maze my_maze(maze_filename, use_gui); // Pass use_gui to the Maze constructor

    std::vector<std::pair<int, int>> path;
    if (search_from(my_maze, my_maze.start_row, my_maze.start_col, path)) {
        std::cout << "Path found:" << std::endl;
        for (const auto& p : path) {
            std::cout << "(" << p.first << ", " << p.second << ")" << std::endl;
        }
    } else {
        std::cout << "No path found." << std::endl;
    }

    // Compare with correct path if provided
    if (!correct_path_filename.empty()) {
        std::ifstream path_file(correct_path_filename);
        std::vector<std::pair<int, int>> correct_path;
        int row, col;
        while (path_file >> row >> col) {
            correct_path.emplace_back(row, col);
        }

        if (path == correct_path) {
            std::cout << "The search path matches the correct path!" << std::endl;
        } else {
            std::cout << "The search path does not match the correct path." << std::endl;
        }
    }

    // Only attempt to call mainloop if the screen has been instantiated
    if (use_gui && my_maze.screen != nullptr) {
        my_maze.screen->mainloop();
    }

    return 0;
}
