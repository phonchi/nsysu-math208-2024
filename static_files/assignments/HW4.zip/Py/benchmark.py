# Author: [Your Name]
# Date: [Date of Creation or Last Update]
# Purpose: 

from random import randint
from timeit import repeat
from typing import Callable, List
sys.path.append("../pythonds3/")
from pythonds3.sorting import merge_sort, quick_sort
from ds_sorting import bubble_sort_bidirection, shell_sort_gap, select_sort_stable, merge_sort_noslice, quick_sort_median, quick_sort_limit

def run_sorting_algorithm(algorithm: Callable, array: List[int], *args, **kwargs):
    # Print message indicating which algorithm is starting its benchmark
    print(f"Running {algorithm.__name__} on array of size {len(array)}...")
    
    # Convert all arguments into string representation
    args_repr = [repr(arg) for arg in args]  # Positional arguments
    kwargs_repr = [f"{k}={repr(v)}" for k, v in kwargs.items()]  # Keyword arguments
    all_args_repr = ", ".join(args_repr + kwargs_repr)  # Combine all argument representations

    # Prepare the setup code and statement for timeit
    setup_code = f"from __main__ import {algorithm.__name__}"
    
    if all_args_repr:  # Check if there are additional arguments
        stmt = f"{algorithm.__name__}({array}, {all_args_repr})"
    else:
        stmt = f"{algorithm.__name__}({array})"

    # Execute the code multiple times and return the minimum time in seconds
    times = repeat(setup=setup_code, stmt=stmt, repeat=3, number=3)
    print(f"Completed {algorithm.__name__}.")
    return min(times)
