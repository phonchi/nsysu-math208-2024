/********************************************************************************
 * Author: [Your Name]
 * Date: [Date of Creation or Last Update]
 * Purpose: 
 ********************************************************************************/

#include <iostream>
#include <vector>
#include <algorithm> // sort for comparison
#include <chrono> // for high_resolution_clock
#include <random> // for mt19937 and distribution
#include <exception>

#include "ds_sorting.h" // Include the header file where your sorting functions are declared
#include "sorting_algorithms.cpp"


using namespace std;

vector<int> generateRandomArray(int size, int min, int max) {
    random_device rd;
    mt19937 gen(rd());
    uniform_int_distribution<> distrib(min, max);
    vector<int> arr(size);
    for (int& it : arr) {
        it = distrib(gen);
    }
    return arr;
}

template<typename SortFunction, typename... Args>
double measureTime(SortFunction sortFunction, std::vector<int>& arr, Args&&... args) {
    const int repeats = 5; // Number of times to repeat the measurement
    double shortestTime = std::numeric_limits<double>::max(); // Initialize with max double value

    for (int i = 0; i < repeats; ++i) {
        auto arrCopy = arr; // Make a copy of the array for each repeat to sort the original unsorted array
        auto start = std::chrono::high_resolution_clock::now();
        sortFunction(arrCopy, std::forward<Args>(args)...); // Perfectly forwarding arguments
        auto finish = std::chrono::high_resolution_clock::now();
        std::chrono::duration<double> elapsed = finish - start;
        double currentTime = elapsed.count();
        if (currentTime < shortestTime) {
            shortestTime = currentTime; // Update shortest time if current iteration is faster
        }
    }
    return shortestTime;
}


int main() {
    // A-1 Test bubble_sort_bidirection
    vector<int> a_list = {20, 30, 40, 90, 50, 60, 70, 80, 100, 110};
    vector<int> b_list;

    // Ascending
    b_list = bubbleSortBidirectional(a_list, false);
    // Descending
    b_list = bubbleSortBidirectional(a_list, true);

    // A-2 Test shell_sort_gap
    // Reset lists for next test
    a_list = {54, 26, 93, 17, 77, 31, 44, 55, 20};
    vector<int> c_list = a_list; // Copy for ascending test

    b_list = shellSortGap(a_list, {5, 3, 1}, false); // Ascending
    b_list = shellSortGap(a_list, {}, false);
    reverse(c_list.begin(), c_list.end()); // Expected result for descending
    b_list = shellSortGap(a_list, {5, 3, 1}, true); // Descending


    // B-1 Test shell_sort_gap
    vector<pair<int, char>> items = {{5, 'A'}, {3, 'A'}, {2, 'A'}, {4, 'A'}, {6, 'A'}, {1, 'A'}, {2, 'B'}};
    vector<pair<int, char>> itemsAfterSort;
    // Correctly call selectSortStable with the key function
    itemsAfterSort = selectSortStable(items, 0);
    itemsAfterSort = selectSortStable(items, 1);


    // B-2 Test merge_sort_noslice
    vector<int> testArray = {54, 26, 93, 17, 77, 31, 44, 55, 20};
    vector<int> correctArray = testArray; // Copy for comparison
    vector<int> testArray2; 
    testArray2 = mergeSortNoSlice(testArray, 0, testArray.size()); // Assuming your function prototype matches this call
    sort(correctArray.begin(), correctArray.end()); // Using std::sort to generate the expected sorted list
    // Benchmarking merge_sort_noslice against a standard merge sort for a large array
    vector<int> largeArray = generateRandomArray(200000, 0, 200000);
    double timeNoslice = measureTime(mergeSortNoSlice, largeArray, 0, largeArray.size());
    double timeStandard = measureTime(mergeSort, largeArray); 

    // C-1 Test quick_sort_median
    vector<int> d_list = generateRandomArray(50000, 0, 200000); // Generate a large test array
    sort(d_list.begin(), d_list.end()); // Sort the copy with std::sort for comparison
    double timeTaken = measureTime(quickSortMedian, d_list);
    double timeTakenStandard = measureTime(quickSort, d_list, 0, largeArray.size()); // This may introduced error
    // Now test quick_sort_median for correctness on a smaller, known array
    a_list = {54, 26, 93, 17, 77, 31, 44, 55, 20};
    b_list = a_list; // Copy for comparison
    c_list = quickSortMedian(a_list);
    sort(b_list.begin(), b_list.end());

    //C-2 Test quick_sort_limit
    vector<int> e_list = generateRandomArray(50000, 0, 200000); // Generate another large test array
    sort(e_list.begin(), e_list.end()); // Sort the copy with std::sort for comparison
    double timeTaken = measureTime(quickSortLimit, e_list, 5000); // Measure time of quick_sort_limit with limit
    double timeTakenStandard = measureTime(quickSort, d_list, 0, largeArray.size()); // This may introduced error
    // Test quick_sort_limit for correctness on known array
    a_list = {54, 26, 93, 17, 77, 31, 44, 55, 20};
    b_list = a_list; // Copy for comparison
    c_list = quickSortLimit(a_list, 5);
    sort(b_list.begin(), b_list.end()); // Expected result 

    return 0;
}
