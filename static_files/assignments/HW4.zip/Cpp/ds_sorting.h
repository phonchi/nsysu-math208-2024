/********************************************************************************
 * Author: [Your Name]
 * Date: [Date of Creation or Last Update]
 * Purpose: 
 ********************************************************************************/

#ifndef SORTING_ALGORITHMS_H
#define SORTING_ALGORITHMS_H

#include <vector>

std::vector<int> bubbleSortBidirectional(std::vector<int> avector, bool descending = false);

std::vector<int> shellSortGap(std::vector<int> avector, const std::vector<int>& gap_sequence = std::vector<int>(), bool descending = false);

std::vector<std::pair<int, char>> selectSortStable(const std::vector<std::pair<int, char>>& avector, size_t key = 0);

std::vector<int> mergeSortNoSlice(const std::vector<int>& avector, int start, int end);

int partitionMedian(std::vector<int>& avector, int first, int last);

std::vector<int> quickSortLimit(std::vector<int> arr, int limit);

#endif // SORTING_ALGORITHMS_H
