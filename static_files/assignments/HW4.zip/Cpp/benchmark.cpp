/********************************************************************************
 * Author: [Your Name]
 * Date: [Date of Creation or Last Update]
 * Purpose: 
 ********************************************************************************/

#include <iostream>
#include <vector>
#include <algorithm> // sort for comparison
#include <chrono> // for high_resolution_clock
#include <random> // for mt19937 and distribution
#include <fstream> // for file output
#include <utility> // For std::forward
#include "ds_sorting.h" // Include the header file where your sorting functions are declared
#include "sorting_algorithms.cpp"


using namespace std;
using namespace chrono;

vector<int> generateRandomArray(int size, int min, int max) {
    random_device rd;
    mt19937 gen(rd());
    uniform_int_distribution<> distrib(min, max);
    vector<int> arr(size);
    for (int& it : arr) {
        it = distrib(gen);
    }
    return arr;
}

template<typename SortFunction, typename... Args>
double measureTime(SortFunction sortFunction, std::vector<int>& arr, Args&&... args) {
    const int repeats = 5; // Number of times to repeat the measurement
    double shortestTime = std::numeric_limits<double>::max(); // Initialize with max double value

    for (int i = 0; i < repeats; ++i) {
        auto arrCopy = arr; // Make a copy of the array for each repeat to sort the original unsorted array
        auto start = std::chrono::high_resolution_clock::now();
        sortFunction(arrCopy, std::forward<Args>(args)...); // Perfectly forwarding arguments
        auto finish = std::chrono::high_resolution_clock::now();
        std::chrono::duration<double> elapsed = finish - start;
        double currentTime = elapsed.count();
        if (currentTime < shortestTime) {
            shortestTime = currentTime; // Update shortest time if current iteration is faster
        }
    }
    return shortestTime;
}


int main() {
 // You need to generate arrays with different sizes according to the specification 
}